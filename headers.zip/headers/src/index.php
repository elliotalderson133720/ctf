<?php
    $flag = file_get_contents("flag.txt");
    header("flag:$flag" );
?>
<h1>There is Only One Hope.</h1>
